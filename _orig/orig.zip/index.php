<?php 
//This header will be used for all pages.  Set the page title here
$pagetitle = 'Home Page';
include('includes/pagetop.php'); 
?>
<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
<script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>

</head>
<body>

<div id="pagewrap">
	<div id="header">
		<?php include('includes/header.php'); ?>	
	</div><!-- end #header -->
	<div style="clear: both;"></div>
	
	<div id="maincontent">
		<div id="homepagegallery">
			<a href="#img1" rel="prettyPhoto[inline]" ><img src="images/homescroll/img1.jpg" alt="" width="184" /></a>
			<a href="#img2" rel="prettyPhoto[inline]" ><img src="images/homescroll/img2.jpg" alt="" width="184" /></a>
			<a href="#img3" rel="prettyPhoto[inline]" ><img src="images/homescroll/img3.jpg" alt="" width="184" /></a>
			<a href="#img4" rel="prettyPhoto[inline]" ><img src="images/homescroll/img4.jpg" alt="" width="184" /></a>
			<a href="#img5" rel="prettyPhoto[inline]" ><img src="images/homescroll/img5.jpg" alt="" width="184" /></a>
			<a href="#img6" rel="prettyPhoto[inline]" ><img src="images/homescroll/img6.jpg" alt="" width="184" /></a>
			<a href="#img7" rel="prettyPhoto[inline]" ><img src="images/homescroll/img7.jpg" alt="" width="184" /></a>
			<a href="#img8" rel="prettyPhoto[inline]" ><img src="images/homescroll/img8.jpg" alt="" width="184" /></a>
			<a href="#img9" rel="prettyPhoto[inline]" ><img src="images/homescroll/img9.jpg" alt="" width="184" /></a>
			<a href="#img10" rel="prettyPhoto[inline]" ><img src="images/homescroll/img10.jpg" alt="" width="184" /></a>
				<div id="img1" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img1.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>
				<div id="img2" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img2.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>
				<div id="img3" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img3.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>
				<div id="img4" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img5.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>
				<div id="img5" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img5.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>
				<div id="img6" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img6.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>
				<div id="img7" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img7.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>
				<div id="img8" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img8.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>
				<div id="img9" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img9.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>
				<div id="img10" style="display: none;">
					<div class="lefthalf">
						<img src="images/homescroll/img10.jpg" alt="" width="184" />
					</div>
					<div class="righthalf">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>
				</div>			
		<div id="bluebox1">
			<div class="blueboxtop"></div>
			<div class="blueboxfield">
				<p>This is a test of box contents</p>
				<p>This is a test of box contents</p>
				<p>This is a test of box contents</p>
				<p>This is a test of box contents</p>
				<p>This is a test of box contents</p>
				<p>This is a test of box contents</p>
				<p>This is a test of box contents</p>
				<p>This is a test of box contents</p>
				<p>This is a test of box contents</p>
				<p>This is a test of box contents</p>				
			</div>
			<div class="blueboxbottom"><a href="#" title="Click to Close">Click to Close [X]</a></div>
		</div>	
		</div><!-- end #homepagegallery -->	
		
		
	</div><!-- end #maincontent -->
	<div style="clear:both;"></div>
	<div id="footer">
		<?php include('includes/footer.php'); ?>
	</div><!-- end #footer -->
	<div style="clear: both;"></div>
</div><!-- end #pagewrap -->
<?php include('includes/pagebottom.php'); ?>