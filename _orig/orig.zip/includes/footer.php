<div id="footertop">
			<p>OUR MISSION:</p>
			<p>Leading <a href="#" title="">health-focused revolution</a> and take control over the quality and longevity of our lives through preventative and regenerative medicine.</p>
		</div>
		
		<div id="footerbottom">
			<div id="footerbottomleft">
				<a href="#" title="Tell Us About Someone"><img src="images/star.gif" alt="Tell Us About Someone" style="float: left; margin-right: 15px;" /></a>
				<h5>Know Someone</h5>
				<p>Don't just sit there, tell us about him or her!</p>
			</div>
			<div id="footerbottomright">
				<a href="#" title="Follow Us On Facebook"><img src="images/fb.png" width="50" style="float: right; margin-left: 10px;" alt="Follow Us on Facebook" /></a>
				<p style="margin-top: 15px;"><a href="mailto:info@medrebels.org" title="">info@medrebels.org</a> 512 468 9780 for more information</p>
			</div>
		</div><!-- end #footerbottom -->