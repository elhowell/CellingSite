		<div id="logo">	
		</div><!-- end #logo -->
		
		<div id="headtopright">
			<a href="#"><img src="images/donatebutton.png" alt="Donate" style="float: right; margin: 10px 25px 0 0;" /></a>
		</div><!-- end #headtopright -->
		
		<div id="headbotright">
		
			<div id="sitedesc">
				<p>The Non-Traditional Non-Profit</p>
			</div><!-- end #sitedesc -->
			
			<div id="mainmenu">
				<?php include('includes/mainmenu.php'); ?>			
			</div><!-- end #mainmenu -->
			
		</div><!-- end #headbotright -->