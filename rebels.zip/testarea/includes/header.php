		<div id="logo">	
		</div><!-- end #logo -->
		
		<div id="headtopright">
			<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=KJJ2MZXVZ35AU&lc=US&item_name=MedRebels%20Foundation&item_number=135&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted"><img src="images/donatebutton.png" alt="Donate" style="float: right; margin: 10px 25px 0 0;" /></a>
		</div><!-- end #headtopright -->
		
		<div id="headbotright">
		
			<div id="sitedesc">
				<p>The non-traditional nonprofit</p>
			</div><!-- end #sitedesc -->
			
			<div id="mainmenu">
				<?php include('includes/mainmenu.php'); ?>			
			</div><!-- end #mainmenu -->
			
		</div><!-- end #headbotright -->
        
        