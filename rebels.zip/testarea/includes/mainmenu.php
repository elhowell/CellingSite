<ul class="sf-menu">
					<li class="current">
						<a href="index.php">Home</a>
						
					</li>
					<li>
						<a href="who-are-we.php">About Us</a>
					
					<ul>
                                    <li><a href="who-are-we.php">Who are we?</a></li>
						
									<li><a href="what-is-cell-therapy.php">What is cell therapy?</a></li>
									<li><a href="what-are-stem-cells.php">What are stem cells?</a></li>
									<li><a href="what-are-adult-stem-cells.php">What are adult stem cells?</a></li>
									<li><a href="what-are-embryonic-stem-cells.php">What are embryonic stem cells?</a></li>
									<li><a href="where-do-stem-cells-come-from.php">Where do stem cells come from?</a></li>
                                    <li><a href="how-is-stem-cell-therapy-used.php">How is stem cell therapy being used?</a></li>
                                    <li><a href="what-obstacles-are-there.php">What obstacles must be overcome?</a></li>
								</ul>
							</li>
							<li><div align="center"><a href="preventative-lifestyle.php">Preventative<br />Lifestyle </a> </div></li>
							
							</li>
							<li><div align="center"><a href="regenerative-health.php">Regenerative<br />Health </a> </div>
								
							</li>
							</li>
							<li>
								<a href="contact.php"><div align="center">Join <br />The Revolution</div></a> </li>
								