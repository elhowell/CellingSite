<div id="footertop">
			<p>OUR MISSION:</p>
			<p>To lead <a href="#" title=""> a health-focused revolution</a> and take control over the quality and longevity of our lives through preventative and regenerative medicine.</p>
		</div>
		
		<div id="footerbottom">
			<div id="footerbottomleft"><br />
				<a href="mailto:info@medrebels.org" title="Tell Us About Someone"><img src="images/star.gif" alt="Tell Us About Someone" style="float: left; margin-right: 15px;" /></a>
				<h5>About Us:</h5>
				<p></p>
                <p></p>
			</div>
			<div id="footerbottomright">
            <a href="http://www.twitter.com/MedRebels"><img src="http://twitter-badges.s3.amazonaws.com/t_logo-a.png" alt="Follow MedRebels on Twitter"/></a>
				<a href="http://www.facebook.com/pages/MedRebels-Foundation/178890225493291?ref=ts" title="Follow Us On Facebook"><img src="images/fb.png" width="50" style="float: right; margin-left: 10px;" alt="Follow Us on Facebook" /></a>
				<p style="margin-top: 15px;"><a href="mailto:info@medrebels.org" title="">info@medrebels.org</a> 512 468 9780 for more information</p>
			</div>
		</div><!-- end #footerbottom -->