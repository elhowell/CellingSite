<div id="footertop">
			<p><strong>OUR MISSION:</strong></p>
			<p>To lead <a href="#" title=""> a health-focused revolution</a> and take control over the quality and longevity of our lives through preventative and regenerative medicine.</p>
			<p><strong>GOAL: </strong></p>
			<p>To raise funds for regenerative medicine research projects and preventative lifestyle programs. </p>
		
		</div>
		
		<div id="footerbottom"><br />
			<div id="footerbottomleft">
	
				<a href="http://medrebels.org/ideas/nominate-a-rebel/" title="Tell Us About Someone"><img src="images/star.gif" alt="Tell Us About Someone" style="float: left; margin-right: 15px;" /></a>
				<h5>Do you know a rebel?</h5>
				<p>Don't just sit there, tell us about him or her!</p></a>
			</div>
			<div id="footerbottomright">
            			<a href="http://www.youtube.com/user/medrebels1"><img src="images/youtube.jpg" alt="Watch our Video here!"/></a>
            			<a href="http://www.twitter.com/MedRebels"><img src="http://twitter-badges.s3.amazonaws.com/t_logo-a.png" alt="Follow MedRebels on Twitter"/></a>
				<a href="http://www.facebook.com/pages/MedRebels-Foundation/178890225493291?ref=ts" title="Follow Us On Facebook"><img src="images/fb.png" width="50" style="float: right; margin-left: 10px;" alt="Follow Us on Facebook" /></a>
				<p><h3><a href="rebelsonrainey.html">Click here for our next event!</a></h3></p>	
				<p style="margin-top: 15px;"><a href="mailto:info@medrebels.org" title="">info@medrebels.org</a> 512 468 9780</p>
<!--				<p style="margin-top: 15px;"><a href="mailto:info@medrebels.org" title="">info@medrebels.org</a> 512 468 9780 for more information</p>		-->
			</div>
		</div><!-- end #footerbottom -->